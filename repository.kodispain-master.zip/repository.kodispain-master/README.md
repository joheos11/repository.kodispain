# repository.kodispain
Repositorio Oficial para kodi. Puedes encontrarme en http://www.konectas.es/ o https://t.me/kodispain/
